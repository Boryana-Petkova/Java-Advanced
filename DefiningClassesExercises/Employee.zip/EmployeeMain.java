package DefiningClassesExercises;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.stream.Collectors;

public class EmployeeMain {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int n = Integer.parseInt(scanner.nextLine());

        List<Employee> EmployeeList = new ArrayList<>();

        for (int i = 0; i < n; i++) {
            String[] tokens = scanner.nextLine().split("\\s+");
            String name = tokens[0];
            double salary = Double.parseDouble(tokens[1]);
            String position = tokens[2];
            String department = tokens[3];
            // останалите две стойности не са задължителни и ще ги търсим по -друг начин

            Employee employee;
            switch (tokens.length){
                case 4:
                    employee = new Employee(name, salary, position, department);
                    break;
                case 5:
                    if (tokens[4].matches("\\d+")) {
                        // matches пита дали e число, тоест \\d+ или [0-9+] което е от regex
                    employee = new Employee(name, salary, position, department,
                            Integer.parseInt(tokens[4]));
                    }else { // ако на 4 индекс от tokens е Стринг ->
                        employee = new Employee(name, salary, position, department,
                                (tokens[4]));
                    }
                    break;
                default:
                    employee = new Employee(name, salary, position, department,
                            tokens[4], Integer.parseInt(tokens[5]));
                    break;
            }
            EmployeeList.add(employee);
        }
        Map.Entry<String, List<Employee>> highestDepartment = EmployeeList.stream().collect(Collectors.groupingBy(Employee::getDepartment))
                .entrySet()
                .stream()
                .sorted((e1, e2) -> {
                    double element1AverageSalary = e1.getValue()
                            .stream()
                            .mapToDouble(Employee::getSalary)
                            .average()
                            .getAsDouble();

                    double element2AverageSalary = e1.getValue()
                            .stream()
                            .mapToDouble(Employee::getSalary)
                            .average()
                            .getAsDouble(); // намираме средна заплата за всеки департамент

                    return Double.compare(element2AverageSalary, element1AverageSalary);
                    // сравняваме в descending order средната заплата
                    // и ни ги подрежда от най-висока средна към най-ниска
                })
                .findFirst()
                .orElse(null);
        // след което намираме първата най-висока средна заплата или нищо

        System.out.printf("Highest Average Salary: %s%n", highestDepartment.getKey());
        highestDepartment.getValue()
                .stream()
                .sorted((e1, e2) -> Double.compare(e2.getSalary(), e1.getSalary()))
                .forEach(System.out::println);
        // сега сортираме по-най-висока заплата и принтираме
    }
}
